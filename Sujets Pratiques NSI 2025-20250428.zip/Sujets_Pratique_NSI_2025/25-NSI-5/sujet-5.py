def crible(n):
    """Renvoie un tableau contenant tous les nombres premiers
    plus petits que n."""
    premiers = []
    tab = [True] * n
    tab[0], tab[1] = False, False
    for i in range(n):
        if tab[i]:
            premiers.... 
            multiple = ... 
            while multiple < n:
                tab[multiple] = ... 
                multiple = ... 
    return premiers


